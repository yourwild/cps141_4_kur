# Brevo Automation

This project provides a Python interface to interact with the Brevo API, specifically for fetching and managing contact attributes for Speechify.

## Project Structure

- `src/brevo_api.py`: Contains the `BrevoAPI` class and utility functions.
- `data/`: Directory where API responses (like `attributes.json`) are stored.
- `.env`: Configuration file for API keys.
- `requirements.txt`: Project dependencies.

## Setup

1. **Install Dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

2. **Configure Environment Variables**:
   Create a `.env` file in the root directory with your Brevo API key:
   ```env
   BREVO_API_KEY=your_api_key_here
   ```

## Usage

### Using the BrevoAPI Class

The `BrevoAPI` class allows you to interact with the Brevo API. It automatically loads the API key from the `.env` file.

```python
from src.brevo_api import BrevoAPI

# Initialize the API client
api = BrevoAPI()

# Fetch contact attributes and save to data/attributes.json
attributes = api.get_contact_attributes()

# Fetch email campaigns and save to data/email_campaigns.json
campaigns = api.get_email_campaigns()

if attributes:
    print("Successfully fetched attributes")
```

### Using the Legacy Function

For quick access, you can use the legacy wrapper function:

```python
from src.brevo_api import get_brevo_attributes

# This will initialize the class and fetch attributes automatically
attributes = get_brevo_attributes()
```

### Running as a Script

You can also run the script directly to update the `data/attributes.json` file. The script now supports command-line arguments:

```bash
# Fetch contact attributes
python src/brevo_api.py --get_contact_attributes

# Fetch email campaigns
python src/brevo_api.py --get_email_campaigns

# Fetch email campaigns and also generate an abridged summary
python src/brevo_api.py --get_email_campaigns --summary

# Interactively select and send an email campaign now
python src/brevo_api.py --send_campaign

# Interactively select and send a test email campaign
python src/brevo_api.py --send_test

# See all available commands
python src/brevo_api.py --help
```

## API Documentation

APIs for this project are sourced from the [Brevo API Reference](https://developers.brevo.com/reference/quickstart-reference).

If you want to add more options to `src/brevo_api.py`, please refer to the [Brevo Developer Documentation](https://developers.brevo.com/).

- **Contact Attributes**: 
  - Endpoint: `GET https://api.brevo.com/v3/contacts/attributes`
  - Output: `data/attributes.json`
- **Email Campaigns**:
  - Endpoint: `GET https://api.brevo.com/v3/emailCampaigns`
  - Output: `data/email_campaigns.json` and `data/email_campaigns_summary.json`
- **Send Campaign Now**:
  - Endpoint: `POST https://api.brevo.com/v3/emailCampaigns/{campaignId}/sendNow`
- **Send Test Campaign**:
  - Endpoint: `POST https://api.brevo.com/v3/emailCampaigns/{campaignId}/sendTest`
