import os
import json
import argparse
import requests
from dotenv import load_dotenv

class BrevoAPI:
    def __init__(self):
        """
        Initializes the BrevoAPI class and loads environment variables.
        """
        # Load environment variables from .env file (looking in parent directory since script is in src/)
        load_dotenv(os.path.join(os.path.dirname(__file__), '..', '.env'))
        self.api_key = os.getenv("BREVO_API_KEY")
        self.base_url = "https://api.brevo.com/v3"
        
        if not self.api_key:
            print("Error: BREVO_API_KEY not found in environment or .env file.")

    def get_contact_attributes(self):
        """
        Fetches all contact attributes from Brevo API and saves them to a JSON file in the data directory.
        """
        if not self.api_key:
            return None

        url = f"{self.base_url}/contacts/attributes"
        headers = {
            "accept": "application/json",
            "api-key": self.api_key
        }

        try:
            response = requests.get(url, headers=headers)
            response.raise_for_status()
            
            attributes = response.json()
            
            # Save the response as json in the data directory
            data_dir = os.path.join(os.path.dirname(__file__), '..', 'data')
            os.makedirs(data_dir, exist_ok=True)
            output_file = os.path.join(data_dir, "contact_attributes.json")
            
            with open(output_file, "w") as f:
                json.dump(attributes, f, indent=4)
            
            # Print summary information
            print("\n--- API Call Summary ---")
            print(f"Status: Success")
            print(f"Endpoint: {url}")
            print(f"File Path: {os.path.abspath(output_file)}")
            print(f"Attributes Found: {len(attributes.get('attributes', []))}")
            print("------------------------\n")

            return attributes

        except requests.exceptions.RequestException as e:
            print(f"Error fetching attributes from Brevo: {e}")
            if hasattr(e, 'response') and e.response is not None:
                print(f"Response: {e.response.text}")
            return None

    def get_email_campaigns(self, generate_summary=False):
        """
        Fetches all email campaigns from Brevo API and saves them to a JSON file in the data directory.
        
        Args:
            generate_summary (bool): If True, also generates a simplified summary JSON file.
        """
        if not self.api_key:
            return None

        url = f"{self.base_url}/emailCampaigns"
        headers = {
            "accept": "application/json",
            "api-key": self.api_key
        }

        try:
            response = requests.get(url, headers=headers)
            response.raise_for_status()
            
            campaigns = response.json()
            
            # Save the response as json in the data directory
            data_dir = os.path.join(os.path.dirname(__file__), '..', 'data')
            os.makedirs(data_dir, exist_ok=True)
            output_file = os.path.join(data_dir, "email_campaigns.json")
            
            with open(output_file, "w") as f:
                json.dump(campaigns, f, indent=4)
            
            summary_file = None
            if generate_summary:
                # Generate and save a simplified summary version
                summary_campaigns = []
                fields_to_include = ['id', 'name', 'subject', 'status', 'sender', 'replyTo', 'toField', 'tag', 'recipients']
                
                for campaign in campaigns.get('campaigns', []):
                    summary_item = {field: campaign.get(field) for field in fields_to_include}
                    summary_campaigns.append(summary_item)
                
                summary_output = {"campaigns": summary_campaigns}
                summary_file = os.path.join(data_dir, "email_campaigns_summary.json")
                
                with open(summary_file, "w") as f:
                    json.dump(summary_output, f, indent=4)

            # Print summary information
            print("\n--- API Call Summary ---")
            print(f"Status: Success")
            print(f"Endpoint: {url}")
            print(f"File Path: {os.path.abspath(output_file)}")
            if summary_file:
                print(f"Summary Data Path: {os.path.abspath(summary_file)}")
            print(f"Campaigns Found: {len(campaigns.get('campaigns', []))}")
            print("------------------------\n")

            return campaigns

        except requests.exceptions.RequestException as e:
            print(f"Error fetching email campaigns from Brevo: {e}")
            if hasattr(e, 'response') and e.response is not None:
                print(f"Response: {e.response.text}")
            return None

    def send_email_campaign_now(self, campaign_id):
        """
        Sends an email campaign now.
        
        Args:
            campaign_id (int): The ID of the campaign to send.
        """
        if not self.api_key:
            return None

        url = f"{self.base_url}/emailCampaigns/{campaign_id}/sendNow"
        headers = {
            "accept": "application/json",
            "api-key": self.api_key
        }

        try:
            response = requests.post(url, headers=headers)
            response.raise_for_status()
            
            # Print summary information
            print("\n--- API Call Summary ---")
            print(f"Status: Success")
            print(f"Endpoint: {url}")
            print(f"Action: Send Campaign Now")
            print(f"Campaign ID: {campaign_id}")
            print("------------------------\n")

            return True

        except requests.exceptions.RequestException as e:
            print(f"Error sending email campaign {campaign_id}: {e}")
            if hasattr(e, 'response') and e.response is not None:
                print(f"Response: {e.response.text}")
            return False

    def send_test_email_campaign(self, campaign_id, email_to=None):
        """
        Sends a test email campaign.
        
        Args:
            campaign_id (int): The ID of the campaign to send.
            email_to (list, optional): List of emails to send the test to.
        """
        if not self.api_key:
            return None

        url = f"{self.base_url}/emailCampaigns/{campaign_id}/sendTest"
        headers = {
            "accept": "application/json",
            "content-type": "application/json",
            "api-key": self.api_key
        }
        
        data = {}
        if email_to:
            data["emailTo"] = email_to

        try:
            response = requests.post(url, headers=headers, json=data)
            response.raise_for_status()
            
            # Print summary information
            print("\n--- API Call Summary ---")
            print(f"Status: Success")
            print(f"Endpoint: {url}")
            print(f"Action: Send Test Campaign")
            print(f"Campaign ID: {campaign_id}")
            if email_to:
                print(f"Sent To: {', '.join(email_to)}")
            print("------------------------\n")

            return True

        except requests.exceptions.RequestException as e:
            print(f"Error sending test email campaign {campaign_id}: {e}")
            if hasattr(e, 'response') and e.response is not None:
                print(f"Response: {e.response.text}")
            return False

def get_contact_attributes():
    """
    Legacy function wrapper to maintain compatibility.
    """
    api = BrevoAPI()
    return api.get_contact_attributes()

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Brevo API Automation Tool")
    parser.add_argument(
        "--get_contact_attributes", 
        action="store_true", 
        help="Fetch all contact attributes and save to data/attributes.json"
    )
    parser.add_argument(
        "--get_email_campaigns", 
        action="store_true", 
        help="Fetch all email campaigns and save to data/email_campaigns.json"
    )
    parser.add_argument(
        "--send_campaign", 
        action="store_true", 
        help="Interactively select and send an email campaign now"
    )
    parser.add_argument(
        "--send_test", 
        action="store_true", 
        help="Interactively select and send a test email campaign"
    )
    parser.add_argument(
        "--summary", 
        action="store_true", 
        help="When used with --get_email_campaigns, also generates a simplified summary JSON file"
    )
    
    args = parser.parse_args()
    api = BrevoAPI()
    
    if args.get_contact_attributes:
        api.get_contact_attributes()
    elif args.get_email_campaigns:
        api.get_email_campaigns(generate_summary=args.summary)
    elif args.send_campaign:
        # 1. Ensure summary exists
        data_dir = os.path.join(os.path.dirname(__file__), '..', 'data')
        summary_file = os.path.join(data_dir, "email_campaigns_summary.json")
        
        if not os.path.exists(summary_file):
            print("Summary file not found. Fetching email campaigns...")
            api.get_email_campaigns(generate_summary=True)
            
        # 2. Load and display summary
        if os.path.exists(summary_file):
            with open(summary_file, 'r') as f:
                data = json.load(f)
                campaigns = data.get('campaigns', [])
                
            if not campaigns:
                print("No campaigns found.")
            else:
                print("\n--- Available Email Campaigns ---")
                for c in campaigns:
                    print(f"ID: {c.get('id')} | Name: {c.get('name')} | Status: {c.get('status')}")
                print("---------------------------------\n")
                
                # 3. Prompt for ID
                try:
                    print("Enter the Campaign ID you want to send now (or type 'cancel' to abort): ")
                    user_input = input("> ").strip().lower()
                    
                    if user_input == 'cancel' or not user_input:
                        print("Operation cancelled.")
                    else:
                        api.send_email_campaign_now(int(user_input))
                except ValueError:
                    print("Invalid input. Please enter a numeric Campaign ID or 'cancel'.")
        else:
            print("Error: Could not find or generate email campaigns summary.")
    elif args.send_test:
        # 1. Ensure summary exists
        data_dir = os.path.join(os.path.dirname(__file__), '..', 'data')
        summary_file = os.path.join(data_dir, "email_campaigns_summary.json")
        
        if not os.path.exists(summary_file):
            print("Summary file not found. Fetching email campaigns...")
            api.get_email_campaigns(generate_summary=True)
            
        # 2. Load and display summary
        if os.path.exists(summary_file):
            with open(summary_file, 'r') as f:
                data = json.load(f)
                campaigns = data.get('campaigns', [])
                
            if not campaigns:
                print("No campaigns found.")
            else:
                print("\n--- Available Email Campaigns ---")
                for c in campaigns:
                    print(f"ID: {c.get('id')} | Name: {c.get('name')} | Status: {c.get('status')}")
                print("---------------------------------\n")
                
                # 3. Prompt for ID
                try:
                    print("Enter the Campaign ID you want to send a test for (or type 'cancel' to abort): ")
                    user_input = input("> ").strip().lower()
                    
                    if user_input == 'cancel' or not user_input:
                        print("Operation cancelled.")
                    else:
                        campaign_id = int(user_input)
                        
                        # 4. Prompt for test emails
                        print("Enter recipient emails separated by comma (optional, press Enter to use default): ")
                        emails_input = input("> ").strip()
                        
                        email_list = None
                        if emails_input:
                            email_list = [e.strip() for e in emails_input.split(',')]
                            
                        api.send_test_email_campaign(campaign_id, email_to=email_list)
                except ValueError:
                    print("Invalid input. Please enter a numeric Campaign ID or 'cancel'.")
        else:
            print("Error: Could not find or generate email campaigns summary.")
    else:
        # Default behavior if no arguments are provided (maintaining existing behavior)
        api.get_contact_attributes()
