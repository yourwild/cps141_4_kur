> For clean Markdown of any page, append .md to the page URL.
> For a complete documentation index, see https://developers.brevo.com/llms.txt.
> For full documentation content, see https://developers.brevo.com/llms-full.txt.
> For AI client integration (Claude Code, Cursor, etc.), connect to the MCP server at https://developers.brevo.com/_mcp/server.

# Overview

A unified REST API for sending messages across email, SMS, and WhatsApp — and managing contacts, tracking custom events, syncing eCommerce data, and building custom objects.

## Where to start

Make your first API call in minutes. The interactive quickstart walks you through authentication and your first request.

Browse API solutions by product area below, or jump to the API reference for full endpoint details.

## Install an SDK

```bash
npm install @getbrevo/brevo
```

[Node.js SDK documentation →](/guides/node-js)

```bash
pip install brevo-python
```

[Python SDK documentation →](/guides/python)

```bash
composer require getbrevo/brevo-php
```

[PHP SDK documentation →](/guides/php)

```bash
curl -X GET https://api.brevo.com/v3/account \
  -H "api-key: YOUR_API_KEY"
```

## Explore by use case

Common integration scenarios and implementation guides.

## API solutions

Explore the most popular integration areas available in the Brevo platform.

Send transactional emails, SMS, and WhatsApp messages. Batch send, schedule deliveries, and track message activity.

Sync and segment contact lists. Import, update, and manage audiences for your
campaigns.

Sync products, categories, and orders. Track customer behavior and attribute
revenue to campaigns.

Integrate live chat widgets and manage conversations programmatically. Customize the chat experience.

Receive real-time event notifications for email, SMS, marketing, and payment
activity.

Track custom user events and behaviors. Monitor website activity and measure engagement with JavaScript or REST APIs.

## Reference & tools

Set up API key or OAuth 2.0 authentication to access the Brevo API.

Understand API rate limits, quotas, and how to handle rate limit responses.

Official SDKs with full API coverage. Available for Node.js, Python, and PHP.

Learn how the Brevo API works. Understand base URLs, authentication, and
request methods.

Explore and test API endpoints with our pre-configured Postman workspace.

Integrate Brevo with AI assistants using the Model Context Protocol.